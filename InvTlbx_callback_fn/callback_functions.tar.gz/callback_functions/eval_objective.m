 
function [jm] = eval_objective(m, usr_par)
% EVAL_OBJECTIVE function to evaluate the objective function at a given
% model m.
%
% Input:
% m : model
% usr_par : auxiliary user defined parameters (optional)
%
% Output:
% jm : objective value (double)
%
% See also EVAL_GRAD_OBJECTIVE and EVAL_OBJECTIVE_AND_GRADIENT.


end