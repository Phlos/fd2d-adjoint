
function [rho, lambda, mu] = map_m_to_parameters(m, usr_par)
% MAP_M_TO_PARAMETERS function to map the model variable m to physical
% parameters rho, lambda and mu.
%
% Input: 
% m
% usr_par : auxiliary user defined parameters (optional)
%
% Output:
% rho 
% lambda
% mu
%
% See also MAP_PARAMETERS_TO_M and MAP_GRADPARAMETERS_TO_GRADM.

end