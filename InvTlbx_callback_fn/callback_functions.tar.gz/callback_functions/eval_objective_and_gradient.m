 
function [jm, gm] = eval_objective_and_gradient(m, usr_par)
% EVAL_OBJECTIVE_AND_GRADIENT function to evaluate the objective function and
% to evaluate the gradient at a given model m.
%
% Input:
% m : model
% usr_par : auxiliary user defined parameters (optional)
%
% Output:
% jm : objective value (double)
% gm : gradient (vector of same size as m)
%
% See also EVAL_OBJECTIVE and EVAL_GRAD_OBJECTIVE.


end