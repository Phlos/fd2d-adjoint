
function [m] = map_parameters_to_m(rho, lambda, mu, usr_par)
% MAP_PARAMETERS_TO_M function to map the physical parameters rho, lambda
% and mu to the model variable m.
%
% Input: 
% rho 
% lambda
% mu
% usr_par : auxiliary user defined parameters (optional)
%
% Output:
% m
%
% See also MAP_M_TO_PARAMETERS and MAP_GRADPARAMETERS_TO_GRADM.

end