 
function [gm] = eval_grad_objective(m, usr_par)
% EVAL_GRAD_OBJECTIVE function to compute the gradient of the objective function at a given model m.
%
% Input:
% m : model
% usr_par : auxiliary user defined parameters (optional)
%
% Output:
% gm : gradient (vector of same size as m)
%
% See also EVAL_OBJECTIVE and EVAL_OBJECTIVE_AND_GRADIENT.



end